import os
os.mkdir('/tmp/Practice_Ayush/majordir/GIT/Helping-Hand/DEV')

